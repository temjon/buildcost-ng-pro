# BuildCost NG Pro

Multi-user SaaS for instant ±10% accurate construction cost estimates in Nigeria using live 2025 market data and AI-powered predictions.

## Features

- **Instant Estimates**: Get construction costs within ±10% accuracy
- **Live Market Data**: 2025 Nigerian construction rates and material prices
- **AI-Powered**: Random Forest + Monte Carlo simulation
- **Multi-Location**: Lagos, Abuja, Port Harcourt, Enugu, and Rural areas
- **PDF Reports**: Professional cost breakdown reports
- **Multi-Language**: English, Hausa, Pidgin support
- **PWA Ready**: Works offline with service worker

## Quick Start

```bash
# Clone and install
npm install

# Setup database
cp .env.example .env
# Edit .env with your database credentials

# Initialize database
npm run db:push
npm run db:seed

# Start development server
npm run dev
```

Visit http://localhost:3000

## Tech Stack

- **Frontend**: Next.js 14, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL
- **Auth**: NextAuth.js
- **PDF**: React-PDF
- **Charts**: Recharts
- **Deployment**: Vercel

## API Endpoints

- `POST /api/estimate` - Generate cost estimate
- `POST /api/pdf` - Generate PDF report
- `GET /api/projects` - List user projects
- `POST /api/admin/prices` - Update material prices (Admin only)

## Development

```bash
npm run dev          # Start dev server
npm run build        # Build for production
npm run db:studio    # Open Prisma Studio
npm run test         # Run tests
```

## Deployment

Deploy to Vercel with one click or use Docker:

```bash
docker-compose up -d
```

## License

Proprietary - BuildCost NG Pro